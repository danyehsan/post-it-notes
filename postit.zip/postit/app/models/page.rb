class Page < ApplicationRecord
end



